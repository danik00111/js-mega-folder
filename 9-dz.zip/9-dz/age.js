function randInt(min, max) {
  min = Math.ceil(min);
  max = Math.floor(max);
  return Math.floor(Math.random() * (max - min + 1)) + min;
}
let age = randInt(0, 80);
if (age < 3) {
  console.log(`${age} baby`);
} else if (age < 10) {
  console.log(`${age} kid`);
} else if (age < 18) {
  console.log(`${age} teen`);
} else if (age < 30) {
  console.log(`${age} young adult`);
} else if (age < 50) {
  console.log(`${age} adult`);
} else if (age >= 50) {
  console.log(`${age} elderly`);
} else {
  console.log(`${age} error`);
}